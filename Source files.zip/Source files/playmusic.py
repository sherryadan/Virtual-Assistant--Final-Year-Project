import pywhatkit

def play_song(song_name):
    # Play the song on YouTube
    pywhatkit.playonyt(song_name)
