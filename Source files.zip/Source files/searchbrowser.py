import pywhatkit

def search_query(query):
    # Search the query on Google
    pywhatkit.search(query)